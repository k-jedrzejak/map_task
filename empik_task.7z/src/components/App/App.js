import './App.css';
import '../Map/Map.css';
import PolandMap from '../Map/Map.js';


function App() {
  return (
    <div className="App">
      <PolandMap />
    </div>
  );
}

export default App;
